Casie Wilford Project 1A Progress README

Use WASD to move.

ESC to exit game.

Backspace to restart level.

Boss moves between 3 set points. After moving 4 times, the Boss will
begin to spin.
The boss begins with 10HP. Once the boss has reached half health, bombs will begin to spawn randomly.

HP Levels:
Player: 3HP
Enemy: 5HP
Boss: 10HP
Killer/ Slower: Unkillable

Repository: https://github.com/CasieWilford/Tank-Controller